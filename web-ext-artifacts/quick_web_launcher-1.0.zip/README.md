# Quick-search
This is a browser extension for quickly searching a site and accessing a site through shortcuts
